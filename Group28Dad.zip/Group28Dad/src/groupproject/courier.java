package groupproject;

import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class courier extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable tasks;
    private DefaultTableModel tableModel;

    // Database credentials
    private static final String url = "jdbc:mysql://localhost:3306/projectdad"; // Replace with your database URL
    private static final String user = "root"; // Replace with your database username
    private static final String password = ""; // Replace with your database password

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    courier frame = new courier();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public courier() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Courier Application");
        setBounds(100, 100, 800, 450); // Adjusted size for better UI layout
        contentPane = new JPanel();
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Create table model with column names
        String[] columnNames = { "Delivery ID", "Courier ID", "Name", "Address", "Phone", "Status" };
        tableModel = new DefaultTableModel(columnNames, 0);

        // Create the JTable with the DefaultTableModel
        tasks = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tasks);
        scrollPane.setBounds(10, 50, 760, 300); // Adjusted bounds for better UI layout
        contentPane.add(scrollPane);

        JLabel lblNewLabel = new JLabel("Delivery Tasks");
        lblNewLabel.setForeground(Color.BLUE); // Set label text color
        lblNewLabel.setBounds(10, 15, 150, 25);
        contentPane.add(lblNewLabel);

        // Populate the table with data from database
        populateTableFromDatabase();
    }

    private void populateTableFromDatabase() {
        try (Connection con = DriverManager.getConnection(url, user, password);
             Statement st = con.createStatement()) {

            // Query to fetch data from deliveries and users tables, sorted by name
            String query = "SELECT d.delivery_id, d.courier_id, u.name, u.address, u.phone, d.delivery_status "
                         + "FROM deliveries d "
                         + "JOIN users u ON d.user_id = u.user_id "
                         + "ORDER BY u.name"; // Sort by name

            ResultSet rs = st.executeQuery(query);

            // Clear existing rows
            tableModel.setRowCount(0);

            // Add rows from ResultSet to table model
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("delivery_id"),
                    rs.getInt("courier_id"),
                    rs.getString("name"),
                    rs.getString("address"),
                    rs.getString("phone"),
                    rs.getString("delivery_status")
                };
                tableModel.addRow(row);
            }

            // Add JComboBox to update status in each row
            for (int row = 0; row < tableModel.getRowCount(); row++) {
                String[] statusOptions = { "Assigned", "In Progress", "Delivered" };
                JComboBox<String> statusCombo = new JComboBox<>(statusOptions);
                statusCombo.setSelectedItem(tableModel.getValueAt(row, 5)); // Set initial selection based on current status
                tasks.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(statusCombo));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
