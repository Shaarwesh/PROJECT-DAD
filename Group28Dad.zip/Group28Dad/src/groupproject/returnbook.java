package groupproject;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultCellEditor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class returnbook extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;

    // Database credentials
    private static final String url = "jdbc:mysql://localhost:3306/projectdad"; // Replace with your database URL
    private static final String user = "root"; // Replace with your database username
    private static final String password = ""; // Replace with your database password
    private JLabel lblNewLabel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    returnbook frame = new returnbook();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public returnbook() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Book Return Application");
        setBounds(100, 100, 800, 500); // Adjusted frame size for better visibility
        contentPane = new JPanel();
        contentPane.setBackground(Color.WHITE); // Set background color
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setLayout(null); // Using null layout for manual component placement

        // Label for the application title
        lblNewLabel = new JLabel("Book Return");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel.setBounds(10, 10, 150, 30);
        contentPane.add(lblNewLabel);

        // Create table model with column names
        String[] columnNames = { "Return ID", "Book ID", "Title", "Author", "Status", "User ID" };
        tableModel = new DefaultTableModel(columnNames, 0);

        // Create the JTable with the DefaultTableModel
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 50, 760, 350); // Adjusted table size and position
        contentPane.add(scrollPane);

        // Add JComboBox to update status in each row
        String[] statusOptions = { "Returned", "Not Returned" };
        JComboBox<String> statusCombo = new JComboBox<>(statusOptions);
        table.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(statusCombo));

        // Populate the table with data from the database
        populateTableFromDatabase();

        // Add a button to save changes
        JButton btnSave = new JButton("Save Changes");
        btnSave.setBackground(Color.BLUE); // Button background color
        btnSave.setForeground(Color.WHITE); // Button text color
        btnSave.setBounds(10, 410, 120, 30); // Adjusted button size and position
        contentPane.add(btnSave);

        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveChangesToDatabase();
            }
        });
    }

    private void populateTableFromDatabase() {
        try (Connection con = DriverManager.getConnection(url, user, password);
             Statement st = con.createStatement()) {

            // Query to fetch data from returns and books tables
            String query = "SELECT r.return_id, r.book_id, b.title, b.author, r.status, r.user_id "
                         + "FROM returns r "
                         + "JOIN book b ON r.book_id = b.book_id";

            ResultSet rs = st.executeQuery(query);

            // Clear existing rows
            tableModel.setRowCount(0);

            // Add rows from ResultSet to table model
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("return_id"),
                    rs.getInt("book_id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("status"),
                    rs.getString("user_id")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void saveChangesToDatabase() {
        try (Connection con = DriverManager.getConnection(url, user, password);
             Statement st = con.createStatement()) {

            // Loop through the table rows to get updated data
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                int returnId = (int) tableModel.getValueAt(i, 0);
                String status = (String) tableModel.getValueAt(i, 4);

                // Update the status in the database
                String updateQuery = "UPDATE returns SET status = '" + status + "' WHERE return_id = " + returnId;
                st.executeUpdate(updateQuery);
            }

            System.out.println("Changes saved successfully!");

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}