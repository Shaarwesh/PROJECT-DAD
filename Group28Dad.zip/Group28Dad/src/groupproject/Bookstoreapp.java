package groupproject;

import java.awt.EventQueue;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Bookstoreapp {

    private JFrame frame;
    private JTable table;
    private JList<String> selectedBooksList;
    private DefaultListModel<String> listModel;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Bookstoreapp window = new Bookstoreapp();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Bookstoreapp() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());
        
        JLabel label = new JLabel("BOOKSTORE APPLICATION");
        label.setFont(new Font("Tahoma", Font.PLAIN, 15));
        frame.getContentPane().add(label, BorderLayout.NORTH);
        
        // Create table model with column names
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Title", "Author", "Status", "Price(RM)"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //Make all cells non-editable
                return false;
            }
        }; // Replace with your actual column names
        
        table = new JTable(model);

        // Enable row sorting
        table.setAutoCreateRowSorter(true);
        
        table.setRowSelectionAllowed(true);
        
        table.setBackground(new Color(204, 255, 204)); // light green
        table.setForeground(Color.BLACK); // black
        table.setSelectionBackground(new Color(0, 128, 0)); // green

        // Add table to a scroll pane and add it to the center of the frame
        JScrollPane tableScrollPane = new JScrollPane(table);
        frame.getContentPane().add(tableScrollPane, BorderLayout.CENTER);
        
        // Create a list for selected books and add it to the east of the frame
        listModel = new DefaultListModel<>();
        selectedBooksList = new JList<>();
        selectedBooksList.setSelectionBackground(new Color(0, 128, 0)); // green
        selectedBooksList.setModel(listModel);
        JScrollPane listScrollPane = new JScrollPane(selectedBooksList);
        frame.getContentPane().add(listScrollPane, BorderLayout.EAST);

        // Add a list selection listener to the table
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    // Get the whole row data
                    String title = (String) table.getValueAt(selectedRow, 0); // Get the title of the selected book
                    String author = (String) table.getValueAt(selectedRow, 1); // Get the author of the selected book
                    String price = (String) table.getValueAt(selectedRow, 3); // Get the price of the selected book

                    // Add the whole row data to the JList
                    listModel.addElement(title + " - " + author + " - RM " + price); 
                }
            }
        });

        
        // Create a panel for the south buttons
        JPanel southPanel = new JPanel();
        southPanel.setBackground(new Color(153, 255, 204)); // light blue
        
        JButton purchaseButton = new JButton("CHECKOUT");
        purchaseButton.setBackground(new Color(0, 128, 0)); // green
        purchaseButton.setForeground(Color.WHITE); // white

        // Add an action listener to the button
        purchaseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Create a new JFrame for the checkout window
                JFrame checkoutFrame = new JFrame("Checkout");
                checkoutFrame.setSize(300, 200);
                checkoutFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                DefaultTableModel checkoutModel = new DefaultTableModel(new Object[]{"No.", "Title", "Price(RM)"}, 0) {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        //Make all cells non-editable
                        return false;
                    }
                };

                JTable checkoutTable = new JTable(checkoutModel);

                double totalPrice = 0.0;

                for (int i = 0; i < listModel.getSize(); i++) {
                    String item = listModel.getElementAt(i);

                    String[] parts = item.split(" - ");
                    String title = parts[0];
                    String priceStr = parts[2].replace("RM ", "");

                    double price = Double.parseDouble(priceStr);
                    totalPrice += price;

                    checkoutModel.addRow(new Object[]{i + 1, title, price});
                }

                checkoutModel.addRow(new Object[] {"", "", ""});
                checkoutModel.addRow(new Object[]{"Total", "", "RM " + totalPrice});

                JScrollPane tableScrollPane = new JScrollPane(checkoutTable);
                checkoutFrame.add(tableScrollPane);

                checkoutFrame.setVisible(true);
            }
        });

        
        JButton removeButton = new JButton("Remove from Checkout List");

        removeButton.setBackground(new Color(0, 128, 0)); // green
        removeButton.setForeground(Color.WHITE); // white

        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int[] selectedIndices = selectedBooksList.getSelectedIndices();

                for (int i = selectedIndices.length - 1; i >= 0; i--) {
                    listModel.remove(selectedIndices[i]);
                }
            }
        });

        
        southPanel.add(purchaseButton);
        southPanel.add(removeButton);

        frame.getContentPane().add(southPanel, BorderLayout.SOUTH);

        populateTableFromDatabase();
    }

    private void populateTableFromDatabase() {
        // Database credentials
        String url = "jdbc:mysql://localhost/projectdad"; // Your database URL
        String user = "root"; // Your username
        String password = ""; // Your password

        try (Connection con = DriverManager.getConnection(url, user, password);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM book")) { 

            DefaultTableModel model = (DefaultTableModel) table.getModel();

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("title"), rs.getString("author"), rs.getString("status"), rs.getString("price")}); 
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}